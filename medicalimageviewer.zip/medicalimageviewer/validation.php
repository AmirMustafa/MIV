<?php
/**
 * Defines the validation message if image is not uploaded
 *
 * This code fragment is called by moodle_needs_upgrading() and
 * /admin/index.php
 *
 * @package   mod_medical_image_viewer
 * @copyright 2019 Virasat Solutions
 * 
 */

echo "You need to upload the image. Please reedit this activity and upload the image";