<?php

echo "You need to upload the image. Please reedit this activity and upload the image";